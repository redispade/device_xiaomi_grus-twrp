<b><#selectbg_g>Terms of Use</#></b>

<b>Important:</b>
This debloater is not "Noob" proof, so think twice before check an app for removing.

I'm not responsible for any possible damage done to your device as a result of flashing.
I'll not take any responsibility for bricked phones or lost data.

If you are not willing to agree with these conditions, don't continue and abort the installation process.

<b><u>WARNING!</b></u>
If you'are about running that script, and delete system apps that will be downloaded as user apps,
be sure to run that script with the same settings to avoid app conflicts.